-- MySQL dump 10.13  Distrib 8.4.10, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: go_server
-- ------------------------------------------------------
-- Server version	8.4.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `go_admin_departments`
--

DROP TABLE IF EXISTS `go_admin_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint unsigned DEFAULT '0',
  `sort` bigint DEFAULT '0',
  `status` bigint DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_go_admin_departments_deleted_at` (`deleted_at`),
  KEY `idx_go_admin_departments_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_departments`
--

LOCK TABLES `go_admin_departments` WRITE;
/*!40000 ALTER TABLE `go_admin_departments` DISABLE KEYS */;
INSERT INTO `go_admin_departments` VALUES (1,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'总公司',0,0,1),(2,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'研发部',1,1,1),(3,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'测试部',1,2,1);
/*!40000 ALTER TABLE `go_admin_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_menu_operations`
--

DROP TABLE IF EXISTS `go_admin_menu_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_menu_operations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `menu_id` bigint unsigned NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_op_method_path` (`method`,`path`),
  KEY `idx_go_admin_menu_operations_deleted_at` (`deleted_at`),
  KEY `idx_go_admin_menu_operations_menu_id` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_menu_operations`
--

LOCK TABLES `go_admin_menu_operations` WRITE;
/*!40000 ALTER TABLE `go_admin_menu_operations` DISABLE KEYS */;
INSERT INTO `go_admin_menu_operations` VALUES (1,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,3,'GET','/api/system/adminUsers/list','管理员列表',1),(2,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,3,'GET','/api/system/adminUsers/:id','管理员详情',2),(3,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,3,'POST','/api/system/adminUsers','新增管理员',3),(4,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,3,'PUT','/api/system/adminUsers/:id','编辑管理员',4),(5,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,3,'DELETE','/api/system/adminUsers/:id','删除管理员',5),(6,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,4,'GET','/api/system/roleMenu/allMenus','所有菜单',1),(7,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,4,'GET','/api/system/roleMenu/roleMenus','角色已分配菜单',2),(8,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,4,'GET','/api/system/roleMenu/roleRoutes','角色已分配路由',3),(9,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,4,'PUT','/api/system/roleMenu/assign','保存权限分配',4),(10,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'GET','/api/system/adminMenus/list','菜单列表',1),(11,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'GET','/api/system/adminMenus/all','所有菜单(带路由)',2),(12,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'GET','/api/system/adminMenus/options','父级菜单下拉',3),(13,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'GET','/api/system/adminMenus/operations/:menu_id','某菜单的路由',4),(14,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'GET','/api/system/adminMenus/:id','菜单详情',5),(15,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'POST','/api/system/adminMenus','新增菜单',6),(16,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'PUT','/api/system/adminMenus/:id','编辑菜单',7),(17,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,5,'DELETE','/api/system/adminMenus/:id','删除菜单',8),(18,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,6,'GET','/api/system/departments','部门列表',1),(19,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,7,'GET','/api/system/adminRoles/list','角色列表',1),(20,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,7,'GET','/api/system/adminRoles/:id','角色详情',2),(21,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,7,'POST','/api/system/adminRoles','新增角色',3),(22,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,7,'PUT','/api/system/adminRoles/:id','编辑角色',4),(23,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,7,'DELETE','/api/system/adminRoles/:id','删除角色',5),(24,'2026-08-05 13:57:25','2026-08-05 13:57:25',NULL,5,'POST','/api/system/adminMenus/operations','POST /api/system/adminMenus/operations',0),(25,'2026-08-05 13:57:25','2026-08-05 13:57:25',NULL,5,'GET','/api/system/adminMenus/operations/get/:id','GET /api/system/adminMenus/operations/get/:id',0),(26,'2026-08-05 13:57:25','2026-08-05 13:57:25',NULL,5,'PUT','/api/system/adminMenus/operations/:id','PUT /api/system/adminMenus/operations/:id',0),(27,'2026-08-05 13:57:25','2026-08-05 13:57:25',NULL,5,'DELETE','/api/system/adminMenus/operations/:id','DELETE /api/system/adminMenus/operations/:id',0);
/*!40000 ALTER TABLE `go_admin_menu_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_menus`
--

DROP TABLE IF EXISTS `go_admin_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT '0',
  `sort` bigint DEFAULT '0',
  `status` bigint DEFAULT '1',
  `data_scope` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_go_admin_menus_code` (`code`),
  KEY `idx_go_admin_menus_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_menus`
--

LOCK TABLES `go_admin_menus` WRITE;
/*!40000 ALTER TABLE `go_admin_menus` DISABLE KEYS */;
INSERT INTO `go_admin_menus` VALUES (1,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'首页','dashboard','/dashboard','HomeFilled',0,100,1,0),(2,'2026-07-31 17:59:09','2026-08-05 16:44:11',NULL,'系统管理','system','/system','Setting',0,90,1,0),(3,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'管理员管理','adminUsers','/system/adminUsers','User',2,91,1,0),(4,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'权限分配','roleMenu','/system/roleMenu','Key',2,92,1,0),(5,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'菜单管理','adminMenus','/system/adminMenus','Menu',2,93,1,0),(6,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'部门管理','departments','/system/departments','OfficeBuilding',2,94,1,0),(7,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'角色管理','adminRoles','/system/adminRoles','Avatar',2,95,1,0);
/*!40000 ALTER TABLE `go_admin_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_role_menus`
--

DROP TABLE IF EXISTS `go_admin_role_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_role_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `menu_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_go_admin_role_menus_role_id` (`role_id`),
  KEY `idx_go_admin_role_menus_menu_id` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_role_menus`
--

LOCK TABLES `go_admin_role_menus` WRITE;
/*!40000 ALTER TABLE `go_admin_role_menus` DISABLE KEYS */;
INSERT INTO `go_admin_role_menus` VALUES (75,2,1),(76,2,2),(77,2,7),(78,2,6),(79,2,5),(80,2,4),(81,2,3),(124,1,1),(125,1,2),(126,1,7),(127,1,6),(128,1,5),(129,1,4),(130,1,3);
/*!40000 ALTER TABLE `go_admin_role_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_role_operations`
--

DROP TABLE IF EXISTS `go_admin_role_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_role_operations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `route_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_go_admin_role_operations_role_id` (`role_id`),
  KEY `idx_go_admin_role_operations_route_id` (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=406 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_role_operations`
--

LOCK TABLES `go_admin_role_operations` WRITE;
/*!40000 ALTER TABLE `go_admin_role_operations` DISABLE KEYS */;
INSERT INTO `go_admin_role_operations` VALUES (223,2,6),(224,2,7),(225,2,8),(226,2,9),(227,2,19),(228,2,20),(229,2,22),(230,2,21),(231,2,23),(232,2,18),(233,2,10),(234,2,11),(235,2,12),(236,2,13),(237,2,14),(238,2,15),(239,2,16),(240,2,17),(241,2,1),(242,2,2),(243,2,3),(244,2,4),(245,2,5),(379,1,1),(380,1,2),(381,1,3),(382,1,4),(383,1,5),(384,1,6),(385,1,7),(386,1,8),(387,1,9),(388,1,10),(389,1,11),(390,1,12),(391,1,13),(392,1,14),(393,1,15),(394,1,16),(395,1,17),(396,1,18),(397,1,19),(398,1,22),(399,1,23),(400,1,20),(401,1,21),(402,1,24),(403,1,25),(404,1,26),(405,1,27);
/*!40000 ALTER TABLE `go_admin_role_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_roles`
--

DROP TABLE IF EXISTS `go_admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `describe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` bigint DEFAULT '1',
  `data_scope` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_go_admin_roles_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_roles`
--

LOCK TABLES `go_admin_roles` WRITE;
/*!40000 ALTER TABLE `go_admin_roles` DISABLE KEYS */;
INSERT INTO `go_admin_roles` VALUES (1,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'超级管理员','拥有所有权限',1,0),(2,'2026-07-31 17:59:09','2026-07-31 18:00:24',NULL,'测试员','测试用角色',1,0);
/*!40000 ALTER TABLE `go_admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_admin_users`
--

DROP TABLE IF EXISTS `go_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_admin_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` bigint DEFAULT '1',
  `role_id` bigint unsigned DEFAULT NULL,
  `department_id` bigint unsigned DEFAULT '0',
  `jumpserver_user_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_go_admin_users_username` (`username`),
  KEY `idx_go_admin_users_deleted_at` (`deleted_at`),
  KEY `idx_go_admin_users_role_id` (`role_id`),
  KEY `idx_go_admin_users_department_id` (`department_id`),
  KEY `idx_go_admin_users_jumpserver_user_id` (`jumpserver_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_admin_users`
--

LOCK TABLES `go_admin_users` WRITE;
/*!40000 ALTER TABLE `go_admin_users` DISABLE KEYS */;
INSERT INTO `go_admin_users` VALUES (1,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'admin','$2a$10$pePzX3q0bl.QXUThm4nSie8CZKE1oh.jPi/N07u1gGbUI89L.Ndsy','admin@example.com','',1,1,1,NULL),(2,'2026-07-31 17:59:09','2026-07-31 17:59:09',NULL,'test2','$2a$10$Sz7lylj6ng69Sg6nnnGmUuaLCZYINorSoAYUVjgoVyT0xJ/PwIOYm','test2@example.com','',1,2,3,NULL),(3,'2026-08-05 14:19:56','2026-08-05 14:19:56','2026-08-05 14:22:01.164','test','$2a$10$pSlrawGP5HOskyrljvkhau8BLjNZaLRiGdMFCkhrlFnEh6mhjvwwG','mrobertvivi11@gmail.com','134586455789',1,1,0,''),(5,'2026-08-05 14:22:28','2026-08-05 14:22:28','2026-08-05 14:24:55.406','test1','$2a$10$Zrr1mYSyKGfFtFCR7ZRGUedwU1Aqh1rZm/r60nk9J0Kjlk3TttxAa','m13robertvivi@gmail.com','13458645587',1,1,0,''),(6,'2026-08-05 14:25:16','2026-08-05 14:25:16',NULL,'test12','$2a$10$OtYuKlbtGV.9LgKZwcWT5e7ujhsCA3nEVcO4WKqhXtm42J9ywSKHu','mrob3ertvivi@gmail.com','13458788895',1,1,0,''),(7,'2026-08-05 14:27:42','2026-08-05 14:27:42',NULL,'rsee','$2a$10$TUy/DKod0R5hpZ3F8qWDJ./XIoeie4g82UlXsCOD34D32xu6Ncc1K','mrobe1rtvivi@gmail.com','13458645505',1,1,0,'');
/*!40000 ALTER TABLE `go_admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_jms_sync_log`
--

DROP TABLE IF EXISTS `go_jms_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_jms_sync_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_user_id` bigint unsigned NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retries` bigint DEFAULT '0',
  `last_error` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_retry_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_go_jms_sync_log_deleted_at` (`deleted_at`),
  KEY `idx_go_jms_sync_log_action` (`action`),
  KEY `idx_go_jms_sync_log_local_user_id` (`local_user_id`),
  KEY `idx_go_jms_sync_log_status` (`status`),
  KEY `idx_go_jms_sync_log_next_retry_at` (`next_retry_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_jms_sync_log`
--

LOCK TABLES `go_jms_sync_log` WRITE;
/*!40000 ALTER TABLE `go_jms_sync_log` DISABLE KEYS */;
INSERT INTO `go_jms_sync_log` VALUES (1,'2026-08-05 14:22:28','2026-08-05 14:32:20',NULL,'create',5,'{\"username\":\"test1\",\"name\":\"test1\",\"email\":\"m13robertvivi@gmail.com\",\"phone\":\"13458645587\",\"password\":\"123456\",\"is_active\":true,\"comment\":\"synced from go_server, local id=5\"}','failed',5,'jms POST /api/v1/users/users/ failed: status=401 msg=身份认证信息未提供。',NULL),(2,'2026-08-05 14:25:16','2026-08-05 14:34:50',NULL,'create',6,'{\"username\":\"test12\",\"name\":\"test12\",\"email\":\"mrob3ertvivi@gmail.com\",\"phone\":\"13458788895\",\"password\":\"123456\",\"is_active\":true,\"comment\":\"synced from go_server, local id=6\"}','failed',5,'jms POST /api/v1/users/users/ failed: status=401 msg=身份认证信息未提供。',NULL),(3,'2026-08-05 14:27:42','2026-08-05 14:37:50',NULL,'create',7,'{\"username\":\"rsee\",\"name\":\"rsee\",\"email\":\"mrobe1rtvivi@gmail.com\",\"phone\":\"13458645505\",\"password\":\"123456\",\"is_active\":true,\"comment\":\"synced from go_server, local id=7\"}','failed',5,'jms POST /api/v1/users/users/ failed: status=401 msg=身份认证信息未提供。',NULL);
/*!40000 ALTER TABLE `go_jms_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_role_menu_relation`
--

DROP TABLE IF EXISTS `go_role_menu_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_role_menu_relation` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `role_id` bigint NOT NULL COMMENT '角色id',
  `menu_id` bigint NOT NULL COMMENT '菜单id',
  `admin_menus_permission` json DEFAULT NULL COMMENT '操作权限id',
  PRIMARY KEY (`id`),
  KEY `idx_go_admin_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色和菜单关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_role_menu_relation`
--

LOCK TABLES `go_role_menu_relation` WRITE;
/*!40000 ALTER TABLE `go_role_menu_relation` DISABLE KEYS */;
INSERT INTO `go_role_menu_relation` VALUES (163,'2026-07-31 15:38:02',NULL,NULL,1,7,NULL),(164,'2026-07-31 15:38:02',NULL,NULL,1,1,NULL),(165,'2026-07-31 15:38:02',NULL,NULL,1,6,NULL),(166,'2026-07-31 15:38:02',NULL,NULL,1,3,NULL),(167,'2026-07-31 15:38:02',NULL,NULL,1,4,NULL),(168,'2026-07-31 15:38:02',NULL,NULL,1,5,NULL),(197,'2026-07-31 16:12:20',NULL,NULL,4,7,NULL),(198,'2026-07-31 16:12:20',NULL,NULL,4,1,NULL),(199,'2026-07-31 16:12:20',NULL,NULL,4,6,NULL);
/*!40000 ALTER TABLE `go_role_menu_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `go_role_permission`
--

DROP TABLE IF EXISTS `go_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `go_role_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=616 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `go_role_permission`
--

LOCK TABLES `go_role_permission` WRITE;
/*!40000 ALTER TABLE `go_role_permission` DISABLE KEYS */;
INSERT INTO `go_role_permission` VALUES (497,1,'system:view'),(498,1,'adminUsers:view'),(499,1,'adminRoles:view'),(500,1,'adminMenus:view'),(501,1,'roleMenu:view'),(502,1,'dashboard:view'),(503,1,'roleMenu:add'),(504,1,'roleMenu:edit'),(505,1,'roleMenu:delete'),(506,1,'roleMenu:detail'),(507,1,'adminUsers:add'),(508,1,'adminUsers:edit'),(509,1,'adminUsers:delete'),(510,1,'adminUsers:detail'),(511,1,'adminRoles:add'),(512,1,'adminRoles:edit'),(513,1,'adminRoles:delete'),(514,1,'adminRoles:detail'),(515,1,'adminMenus:add'),(516,1,'adminMenus:edit'),(517,1,'adminMenus:delete'),(518,1,'adminMenus:detail'),(611,4,'system:view'),(612,4,'roleMenu:view'),(613,4,'dashboard:view'),(614,4,'roleMenu:delete'),(615,4,'roleMenu:detail');
/*!40000 ALTER TABLE `go_role_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 11:18:06
